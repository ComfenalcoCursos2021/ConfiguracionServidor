<?php
echo "<h1>Comfenalco/CURSO-JAVASCRIPT-DFBLJ-20211-2021 </h1><hr>";
$cadena = "<table>";
$thefolder = "./";
if ($handler = opendir($thefolder)) {
    while (false !== ($file = readdir($handler))) {
        if($file != ".." && $file != "." && $file != "folder.gif" && $file != ".htaccess" && $file != "index.php" && $file != ".grid"  ){
            $cadena .= "<tr>
                    <td><img src='folder.gif'><a href='/$file'> $file</a></td>
                </tr>";
        }
            
    }
    closedir($handler);
}
$cadena .= "</table>";
echo $cadena;
?>